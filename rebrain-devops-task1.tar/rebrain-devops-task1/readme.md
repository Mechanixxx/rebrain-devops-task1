Default config file of nginx


